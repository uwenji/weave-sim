// sequence.js — the sequence planner v2 (document/Planning method.md §4–§5): crossing by crossing, K weavers in rounds.
//
// The unit is the piece — a physical strip. A strip is cut when it is threaded: from the crossing where the front first
// needs its strand it runs along the strand — first through the crossings of the front's ring, then ahead of it — until
// the material (or a cut length) ends, the strand ends, another strip lies there (the two are joined), the strand turns
// back toward the front, or, with several weavers, another weaver's front will reach it first (cut there, joined at the
// seam). A strip is woven from where it was threaded, contiguously: a crossing may wait for its partner one at a time
// (G = 1, R9) — never woven at both ends with the middle free. A joint (O1) pushes the later strip's end backwards
// through the earlier strip's last k crossings once both are woven up to there; a strip around a closed strand meets
// its own start the same way. A strip that would block the front is cut shorter after the fact (the plan is made before
// anyone weaves, so the cut is simply decided earlier).
//
// The weavers start from the rims — a tube from its bottom ring, a tree from its trunk base, the columns from their feet;
// a closed shape from the lower end of its longest axis (Ji, 8 Nov: "ring to ring, based on my study of people's weaving
// paths"). The front is a strict ring: a weaver finishes its ring (hop level from its seed) before it starts the next,
// one ahead only when nothing is left on its ring. Several weavers share one front by default (`front: 'together'`):
// the rings are counted from one start, the weavers begin spread along it, each works the part of its ring nearer to it
// than to the others (or the next ring near it, never back down) and strips pass from hand to hand; with `front: 'rims'`
// each weaver has a front of its own from its own rim, and where two fronts meet head-on the strands are cut and joined. Each round every weaver makes one crossing, the cheapest by the rules
// as costs — a new strip costs as much as it will hang (the load of its remainder: a long remainder weighs, not only
// waits — Ji), closing cells and strips pays, so do continuing the strip in hand and staying near; jumps, turns, joints
// and hand-overs (the weaver who moves a strip holds it — O6) cost. Where the fronts meet is a result (O5).

import { Sequencer, featuresOf, replay } from './sequencer.js';
import { chooseStart, neighbours, hopDistance } from './planner.js';

const WEIGHTS = { newPiece: 4, ringFresh: 0.15, join: 1, cellClosed: 2, pieceDone: 2, jump: 4, far: 10, turn: 1.0, handover: 2, feature: 1, featureNew: 0.5, stress: 1, fill: 1.5, support: 2, sameMover: 1, level: 3, load: 0.25 };

export function planSequence(w, opts = {}) {
  const G = opts.G ?? 1, k = Math.max(0, opts.k ?? 2), Lmax = opts.Lmax > 0 ? opts.Lmax : Infinity, R = opts.radius ?? 3, ahead = opts.ahead ?? 0;
  const Lcut = Math.min(Lmax, opts.cut > 0 ? opts.cut : Infinity);
  const W = { ...WEIGHTS, ...(opts.weights || {}) };
  const nbr = neighbours(w), aMed = (() => { const l = Array.from(w.edgeLen).sort((x, y) => x - y); return l[l.length >> 1] || 1; })();
  // --- seeds: a rim loop or a cell per weaver. Given (cells / arrays of cells: a rim cell stands for its loop), from a
  //     start rule of the cell tour (for comparison), or by default the rims from the lowest up, then the ends of the shape
  const loops = boundaryLoops(w, nbr), loopOf = new Int32Array(w.nV).fill(-1); loops.forEach((l, i) => { for (const v of l) loopOf[v] = i; });
  const asSeed = (v) => (loopOf[v] >= 0 ? loops[loopOf[v]].slice() : [v]);
  const Kwant = Math.max(1, opts.K | 0 || 1);
  let seeds = null, origin = null, startWhy = null;
  if ((opts.front ?? 'together') === 'together' && Kwant > 1) {
    // one front for all: the rings are counted from one start (the K = 1 start, or the given one), the weavers begin
    // spread along it and work the same ring side by side — a strip passes from hand to hand (O6), no seam
    const given = Array.isArray(opts.seeds) && opts.seeds.length ? opts.seeds[0] : null;
    origin = given != null ? (Array.isArray(given) ? given.slice() : asSeed(given)) : opts.rule && opts.rule !== 'rims' ? asSeed(chooseStart(w, nbr, opts.rule).cell) : (startWhy = autoStart(w, nbr)).src;
    seeds = spreadStarts(w, nbr, origin, Kwant).map(v => [v]);
  } else {
    seeds = Array.isArray(opts.seeds) && opts.seeds.length ? opts.seeds.map(sd => (Array.isArray(sd) ? sd.slice() : asSeed(sd))) : null;
    if (seeds && seeds.length < Kwant) seeds = fillSeeds(w, nbr, seeds, Kwant);
    if (!seeds && opts.rule && opts.rule !== 'rims') seeds = fillSeeds(w, nbr, [asSeed(chooseStart(w, nbr, opts.rule).cell)], Kwant);
    if (!seeds) { startWhy = autoStart(w, nbr); seeds = Kwant > 1 ? autoSeeds(w, Kwant, nbr) : [startWhy.src]; }
  }
  const K = seeds.length, seq = new Sequencer(w, { G, k, weavers: K });
  // --- strand geometry: chord between consecutive knots, wrapping on a closed strand -----------------------------------
  const M = w.edgeMid, dist = (a, b) => Math.hypot(M[3 * a] - M[3 * b], M[3 * a + 1] - M[3 * b + 1], M[3 * a + 2] - M[3 * b + 2]);
  const SG = w.strands.map((s) => {
    const Kn = s.knots.length, seg = new Float64Array(Kn);
    for (let i = 0; i < Kn; i++) seg[i] = i + 1 < Kn ? dist(s.knots[i], s.knots[i + 1]) : (s.closed ? dist(s.knots[Kn - 1], s.knots[0]) : 0);
    return { Kn, closed: s.closed, seg, knots: s.knots };
  });
  const idx = (si, u) => { const { Kn, closed } = SG[si]; return closed ? ((u % Kn) + Kn) % Kn : u; };
  const valid = (si, u) => SG[si].closed || (u >= 0 && u < SG[si].Kn);
  const segAt = (si, u) => SG[si].seg[idx(si, u)];                        // chord between unwrapped positions u and u + 1
  /** the length of a strip over unwrapped positions [lo, hi]: chords plus half a chord at each end */
  const spanLength = (si, lo, hi) => {
    let L = 0; for (let u = lo; u < hi; u++) L += segAt(si, u);
    if (valid(si, lo - 1)) L += segAt(si, lo - 1) / 2;
    if (valid(si, hi + 1)) L += segAt(si, hi) / 2;
    return L;
  };
  /** the strip a joint adds beyond an end: n chords past position endU on side sd */
  const overlapLen = (si, endU, sd, n) => { let L = 0; for (let q = 0; q < n; q++) { if (!valid(si, endU + sd * (q + 1))) break; L += sd > 0 ? segAt(si, endU + q) : segAt(si, endU - 1 - q); } return L; };
  // --- features (R7) and singular rings (R8) --------------------------------------------------------------------------
  const { singular, feats } = featuresOf(w, seq);
  const featOf = Array.from({ length: w.nE }, () => []);
  feats.forEach((f, fi) => { f.made = 0; f.total = f.cross.length; for (const e of f.cross) featOf[e].push(fi); });
  const ringOf = Array.from({ length: w.nE }, () => []);
  const ringSets = singular.map((c) => { const set = new Set(); for (const v of [c, ...nbr[c]]) for (const e of seq.cellCross[v]) set.add(e); return { c, set, made: 0, total: set.size, started: false }; });
  ringSets.forEach((r, ri) => { for (const e of r.set) ringOf[e].push(ri); });
  // --- the weavers: hop levels of the cells from the seed; a crossing's level is the farther of its two cells -------------
  const levShared = origin ? hopDistance(w, origin, nbr) : null;
  const weavers = seeds.map((seed, wv) => {
    const lev = levShared || hopDistance(w, seed, nbr), elev = new Int32Array(w.nE), remaining = [];
    for (let e = 0; e < w.nE; e++) { const [a, b] = w.edges[e]; elev[e] = Math.max(lev[a] < 0 ? 0 : lev[a], lev[b] < 0 ? 0 : lev[b]); if (seq.isCross[e]) remaining[elev[e]] = (remaining[elev[e]] || 0) + 1; }
    return { wv, seed, last: -1, lastPiece: -1, prevVec: null, idle: 0, acts: 0, elev, remaining, L: 0 };
  });
  const frontLevel = (wr) => { while (wr.L < wr.remaining.length && !(wr.remaining[wr.L] > 0)) wr.L++; return wr.L; };
  const noteMade = (e) => { for (const wr of weavers) wr.remaining[wr.elev[e]]--; };

  // --- strips -------------------------------------------------------------------------------------------------------------
  // a piece: Sequencer piece + { lo, hi: its own extent (unwrapped strand positions), u0: the position of knots[0]
  // (lower than lo once its tail joint is pushed in), nb: {1, -1}: the strip it is joined to at that end ({id, n} or
  // null), self: a closed strand's strip that meets its own start, joined: {1, -1}, born, wv }
  const pendingJ = new Set();
  const covering = (si, u) => { const l = seq.pieceOfKnot[si][idx(si, u)]; return l.length ? seq.pieces[l[0]] : null; };
  /** the extent of a new strip threaded at strand position u0 by weaver wv */
  const plannedExtent = (si, u0, wv) => {
    const lev = weavers[wv].elev, others = weavers.filter(o => o.wv !== wv), { Kn, closed } = SG[si];
    const levAt = (u) => lev[SG[si].knots[idx(si, u)]];
    let lo = u0, hi = u0, inner = 0, self = false;
    const S = { 1: { open: true, max: levAt(u0), nb: null }, '-1': { open: true, max: levAt(u0), nb: null } };
    // the exact length of the strip over [l, h] with nT / nH crossings of joint pushed in at its tail / head, half a
    // chord past each physical end
    const clampN = (end, sd, n) => { let q = 0; while (q < n && valid(si, end + sd * (q + 1))) q++; return q; };
    const exactLen = (l, h, inn, nT, nH) => {
      const t = clampN(l, -1, nT), hh = clampN(h, 1, nH); let L = inn;
      for (let q = 0; q < t; q++) L += segAt(si, l - 1 - q);
      for (let q = 0; q < hh; q++) L += segAt(si, h + q);
      if (valid(si, l - t - 1)) L += segAt(si, l - t - 1) / 2;
      if (valid(si, h + hh + 1)) L += segAt(si, h + hh) / 2;
      return L;
    };
    const nTail = () => (S[-1].nb ? S[-1].nb.n : 0), nHead = (full) => (S[1].nb ? S[1].nb.n : full ? k : 0);
    for (let guard = 0; guard < 2 * Kn + 4; guard++) {
      if (closed && hi - lo + 1 >= Kn) { self = true; break; }
      let sd = 0, best = Infinity;                                         // the side whose next crossing lies lower: the ring first, then ahead
      for (const s of [1, -1]) { if (!S[s].open) continue; const u = s > 0 ? hi + 1 : lo - 1; if (!valid(si, u)) { S[s].open = false; S[s].why = 'end'; continue; } const l = levAt(u); if (l < best) { best = l; sd = s; } }
      if (!sd) break;
      const u = sd > 0 ? hi + 1 : lo - 1, Sd = S[sd];
      const N = covering(si, u);
      if (N) { Sd.open = false; Sd.nb = { id: N.id, n: Math.min(k, N.knots.length) }; Sd.why = 'joint'; continue; }
      const e = SG[si].knots[idx(si, u)], l = lev[e];
      if (l < Sd.max - 1) { Sd.open = false; Sd.why = 'turn'; continue; }   // the strand turns back toward the front
      if (hi - lo + 1 >= 2 * k + 1 && others.some(o => o.elev[e] + 2 < l)) { Sd.open = false; Sd.why = 'seam'; continue; }   // another weaver's front gets there clearly first: the seam (once the strip can be joined)
      const nlo = sd < 0 ? u : lo, nhi = sd > 0 ? u : hi, nin = inner + (sd > 0 ? segAt(si, hi) : segAt(si, u));
      const full = closed && nhi - nlo + 1 >= Kn;
      if (exactLen(nlo, nhi, nin, nTail(), nHead(full)) > Lcut + 1e-9) { Sd.open = false; Sd.why = 'length'; continue; }   // the strip's length
      lo = nlo; hi = nhi; inner = nin; Sd.max = Math.max(Sd.max, l);
    }
    // a joint found last may not fit any more: shorten the strip from an end that meets nothing (or drop that joint)
    let length = exactLen(lo, hi, inner, nTail(), nHead(self));
    for (let guard = 0; length > Lcut + 1e-9 && hi > lo && guard < 2 * Kn; guard++) {
      if (self) { self = false; S[1].why = 'length'; S[-1].why = 'length'; }
      const sd = !S[1].nb && hi > u0 ? 1 : !S[-1].nb && lo < u0 ? -1 : hi - u0 >= u0 - lo ? 1 : -1;
      if (S[sd].nb) { S[sd].nb = null; }
      S[sd].why = 'length';
      if (sd > 0) { inner -= segAt(si, hi - 1); hi--; } else { inner -= segAt(si, lo); lo++; }
      length = exactLen(lo, hi, inner, nTail(), nHead(false));
    }
    // the material is shorter than a crossing and its joints: the overlap of a joint shrinks (to one crossing at least)
    let short = 0;
    for (let guard = 0; length > Lcut + 1e-9 && guard < 4 * k + 4; guard++) {
      const sd = S[1].nb && S[1].nb.n > 1 && (!S[-1].nb || S[1].nb.n >= S[-1].nb.n) ? 1 : S[-1].nb && S[-1].nb.n > 1 ? -1 : 0;
      if (!sd) break;
      S[sd].nb = { ...S[sd].nb, n: S[sd].nb.n - 1 }; short = 1;
      length = exactLen(lo, hi, inner, nTail(), nHead(self));
    }
    return { lo, hi, nb: { 1: S[1].nb, '-1': S[-1].nb }, self, length, short, over: length > Lcut + 1e-9 ? 1 : 0, why: { 1: self ? 'self' : S[1].why || 'end', '-1': self ? 'self' : S[-1].why || 'end' } };
  };
  let shortJoints = 0, overLong = 0;
  const introduce = (si, u0, wv, ext) => {
    shortJoints += ext.short; overLong += ext.over;
    const knots = []; for (let u = ext.lo; u <= ext.hi; u++) knots.push(idx(si, u));
    const pc = seq.addPiece({ si, knots, holder: wv });
    Object.assign(pc, { why: ext.why, lo: ext.lo, hi: ext.hi, u0: ext.lo, nb: ext.nb, self: ext.self, joined: { 1: !ext.nb[1] && !ext.self, '-1': !ext.nb[-1] }, born: seq.t, wv, threadAt: u0, ovHead: 0, ovTail: 0, planned: ext.length });
    if (!pc.joined[1] || !pc.joined[-1]) pendingJ.add(pc.id);
    return pc;
  };
  const posOf = (pc, u) => u - pc.u0;                                       // index in pc.knots of unwrapped position u
  /** is the strip woven up to its own end on side sd (its outermost crossing there made)? */
  const wovenToEnd = (pc, sd) => {
    for (let u = sd > 0 ? pc.hi : pc.lo; sd > 0 ? u >= pc.lo : u <= pc.hi; u -= sd) { const m = posOf(pc, u); if (pc.cross[m]) return !!pc.madeMask[m]; }
    return true;
  };
  let joins = 0, handovers = 0, seams = 0, cuts = 0, strandedSum = 0, strandedMax = 0, actions = 0;
  /** the joint at end sd of strip Q: its end pushed backwards through the k woven crossings of the strip it meets */
  const tryJoin = (Q, sd, wv) => {
    if (Q.joined[sd]) return false;
    const si = Q.si, target = sd > 0 && Q.self ? { id: Q.id, n: k } : Q.nb[sd];
    if (!target) { Q.joined[sd] = true; return false; }
    if (!wovenToEnd(Q, sd)) return false;
    const end = sd > 0 ? Q.hi : Q.lo, positions = [];
    for (let q = 1; q <= target.n; q++) {
      const u = end + sd * q; if (!valid(si, u)) break;
      const i = idx(si, u), e = SG[si].knots[i];
      if (!seq.pieceOfKnot[si][i].includes(target.id)) break;
      if (seq.isCross[e] && !seq.made[e]) return false;                    // O1: only through woven crossings
      positions.push(u);
    }
    Q.joined[sd] = true;
    if (!positions.length) return false;                                   // the strip it was to meet is no longer there: a free end
    for (const u of positions) { seq.extendPiece(Q, sd, idx(si, u)); if (sd < 0) Q.u0--; }
    const Lk = Q.knots.length, pos = [];
    for (let q = 0; q < positions.length; q++) { const m = sd > 0 ? Lk - positions.length + q : q; if (seq.isCross[Q.edges[m]]) pos.push(m); }
    if (pos.length) seq.join(Q.id, target.id, wv, pos);
    if (sd > 0) Q.ovHead = positions.length; else Q.ovTail = positions.length;
    joins++;
    return true;
  };
  const runJoins = (wv) => { for (const id of [...pendingJ]) { const Q = seq.pieces[id]; for (const sd of [1, -1]) tryJoin(Q, sd, Q.holder ?? wv); if (Q.joined[1] && Q.joined[-1]) pendingJ.delete(id); } };

  /** how the slot (si, i) of crossing e is served now: an existing strip (if it stays contiguous) or a new one; null =
   *  not now. `cache` keeps the planned extents of one decision */
  const slotPlan = (si, i, e, wv, cache) => {
    const l = seq.pieceOfKnot[si][i];
    if (l.length) { const P = seq.pieces[l[0]]; return seq.gapIfMade(P, e) <= G ? { kind: 'covered', piece: P } : null; }
    const key = si * 65536 + i; let ext = cache.get(key);
    if (!ext) { ext = plannedExtent(si, i, wv); cache.set(key, ext); }
    return { kind: 'fresh', ext, si, i };
  };
  const planOf = (e, wv, cache) => {
    const out = []; for (const [si, i] of seq.slots[e]) { const r = slotPlan(si, i, e, wv, cache); if (!r) return null; out.push(r); }
    // a strand crossing itself: a strip threaded at the first pass that also reaches the second would be woven at both
    // passes with the strip between them free (R9) — this crossing waits until the strip is woven up to there
    if (out.length === 2 && out[0].kind === 'fresh' && out[1].kind === 'fresh' && out[0].si === out[1].si) {
      const { ext, si } = out[0]; let lo = Infinity, hi = -Infinity;
      for (let u = ext.lo; u <= ext.hi; u++) if (SG[si].knots[idx(si, u)] === e) { lo = Math.min(lo, u); hi = Math.max(hi, u); }
      if (hi - lo - 1 > G) return null;
    }
    return out;
  };

  // --- one crossing --------------------------------------------------------------------------------------------------------
  const vec = (a, b) => [M[3 * b] - M[3 * a], M[3 * b + 1] - M[3 * a + 1], M[3 * b + 2] - M[3 * a + 2]];
  const angle = (u, v) => { const lu = Math.hypot(...u), lv = Math.hypot(...v); if (!lu || !lv) return 0; return Math.acos(Math.max(-1, Math.min(1, (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (lu * lv)))) * 180 / Math.PI; };
  /** open strips the front has left behind: their next crossing lies below the weaver's ring */
  const strandedCount = (wr) => {
    let n = 0;
    for (const P of seq.pieces) {
      if (P.intro < 0 || P.madeN >= P.nCross) continue;
      let lv = Infinity; for (let m = 0; m < P.knots.length; m++) if (P.cross[m] && !P.madeMask[m]) lv = Math.min(lv, wr.elev[P.edges[m]]);
      if (lv < wr.L) n++;
    }
    return n;
  };
  const act = (wr, e) => {
    const wv = wr.wv, involved = [];
    for (const [si, i] of seq.slots[e]) {                                   // slot by slot: a strip threaded for the first slot may cover the second
      const l = seq.pieceOfKnot[si][i];
      if (l.length) { involved.push(seq.pieces[l[0]]); continue; }
      involved.push(introduce(si, i, wv, plannedExtent(si, i, wv)));
    }
    let mover = -1, bestT = -2;                                             // the strip in this weaver's hands moved most recently, else a new one
    for (const P of involved) if (P.holder === wv && P.lastT > bestT) { bestT = P.lastT; mover = P.id; }
    if (mover < 0) { const f = involved.find(P => P.intro < 0); mover = (f || involved[0]).id; }
    const holders = new Set(involved.map(P => P.holder));
    const ev = seq.weave(e, wv, mover);
    noteMade(e);
    if (ev.handover >= 0) handovers++;
    if (holders.size > 1) { seams++; ev.seam = true; }
    for (const fi of featOf[e]) feats[fi].made++;
    for (const ri of ringOf[e]) { ringSets[ri].made++; ringSets[ri].started = true; }
    if (wr.last >= 0) wr.prevVec = vec(wr.last, e);
    wr.last = e; wr.lastPiece = mover; wr.acts++;
    if (actions % 4 === 0) { frontLevel(wr); const st = strandedCount(wr); strandedSum += st * 4; if (st > strandedMax) strandedMax = st; }
    actions++;
    runJoins(wv);
  };
  const cost = (wr, e, plan, d) => {
    let c = 0, fill = 0, own = false;
    for (const r of plan) if (r.kind === 'covered' && r.piece.holder === wr.wv) own = true;
    for (const r of plan) {
      if (r.kind === 'fresh') {
        // on the weaver's own ring a new strip cannot be avoided, only put off: its cost is a tie-breaker there, so the
        // ring is swept in order instead of hopping back and forth to thread late
        const f = wr.elev[e] <= (wr.Lw ?? wr.L) ? W.ringFresh : 1;
        c += f * (W.newPiece + W.load * r.ext.length / aMed) + W.join * ((r.ext.nb[1] ? 1 : 0) + (r.ext.nb[-1] ? 1 : 0) + (r.ext.self ? 1 : 0));
      } else {
        const P = r.piece; fill++;
        if (P.holder !== wr.wv && P.intro >= 0 && !own) c += W.handover;
        if (P.madeN + seq.positionsOf(P, e).filter(m => !P.madeMask[m]).length >= P.nCross) c -= W.pieceDone;
      }
    }
    let cells = 0; for (const v of w.edges[e]) if (!seq.closed[v] && seq.ringN[v] > 0 && seq.cellMade[v] + 1 === seq.ringN[v]) cells++;
    const nb = seq.crossNbr[e]; let sup = 0; for (const f of nb) if (seq.made[f]) sup++;
    const same = plan.some(r => r.kind === 'covered' && r.piece.id === wr.lastPiece) ? 1 : 0;
    c += -W.cellClosed * cells - W.fill * fill - W.support * (nb.length ? sup / nb.length : 0) - W.sameMover * same;
    if (d >= 2) c += W.jump * (d - 1); if (d > R) c += W.far;
    const ah = wr.elev[e] - (wr.Lw ?? wr.L); if (ah > 0) c += W.level * ah;
    if (wr.prevVec && wr.last >= 0 && d <= 2) c += W.turn * angle(wr.prevVec, vec(wr.last, e)) / 90;
    let featBonus = 0, featNew = 0;
    for (const fi of featOf[e]) { const f = feats[fi]; if (f.made > 0 && f.made < f.total) featBonus = 1; else if (f.made === 0 && feats.some(g => g.kind === f.kind && g.made > 0 && g.made < g.total)) featNew = 1; }
    c += -W.feature * featBonus + W.featureNew * featNew;
    for (const ri of ringOf[e]) if (ringSets[ri].started && ringSets[ri].made < ringSets[ri].total) { c -= W.stress; break; }
    return c;
  };
  /** unmade crossings around e0 by lattice distance (BFS over crossings sharing a cell) */
  const near = (e0) => {
    const dist = new Map([[e0, 0]]); let frontier = [e0]; const out = [];
    for (let d = 1; frontier.length; d++) {
      const next = [];
      for (const e of frontier) for (const f of seq.crossNbr[e]) if (!dist.has(f)) { dist.set(f, d); next.push(f); if (!seq.made[f]) out.push([f, d]); }
      frontier = next;
      if (d >= R && out.length) break;
    }
    return out;
  };
  /** a strip that blocks the nearest unmade crossing (woven too far from it) is cut back to its woven part */
  const repair = (wr) => {
    let best = -1, bd = Infinity;
    for (let e = 0; e < w.nE; e++) if (seq.isCross[e] && !seq.made[e]) { const d = wr.last >= 0 ? seq.crossDistance(wr.last, e, 8) : wr.elev[e]; if (d < bd) { bd = d; best = e; } }
    if (best < 0) return false;
    let did = false;
    for (const [si, i] of seq.slots[best]) {
      const l = seq.pieceOfKnot[si][i]; if (!l.length) continue;
      const P = seq.pieces[l[0]]; if (seq.gapIfMade(P, best) <= G) continue;
      let mlo = Infinity, mhi = -1; P.madeMask.forEach((x, m) => { if (x) { mlo = Math.min(mlo, m); mhi = Math.max(mhi, m); } });
      const ms = seq.positionsOf(P, best).find(m => !P.madeMask[m] && (m > mhi + G || m < mlo - G));
      if (ms === undefined) continue;
      if (ms > mhi) { const n = P.knots.length - ms; seq.trimPiece(P, 1, n); P.hi -= n; P.nb[1] = null; P.self = false; P.joined[1] = true; }
      else { const n = ms + 1; seq.trimPiece(P, -1, n); P.lo += n; P.u0 += n; P.nb[-1] = null; P.joined[-1] = true; }
      cuts++; did = true;
    }
    return did;
  };

  // --- one front for all: a weaver works the crossings of the ring that are nearer to it than to the others (the next
  //     ring near it when the rest of this one is the others' — nobody reaches across a neighbour); lattice distance
  //     from where each weaver is, over the crossings ----------------------------------------------------------------------
  const together = !!origin;
  const distFrom = (srcs) => {
    const D = new Int32Array(w.nE).fill(1 << 29); let frontier = [];
    for (const e of srcs) if (D[e] > 0) { D[e] = 0; frontier.push(e); }
    for (let d = 1; frontier.length; d++) { const next = []; for (const e of frontier) for (const f of seq.crossNbr[e]) if (D[f] > d) { D[f] = d; next.push(f); } frontier = next; }
    return D;
  };
  if (together) for (const wr of weavers) { wr.dmap = distFrom([...new Set(wr.seed.flatMap(v => seq.cellCross[v]))]); wr.Lw = 0; }

  // --- the rounds ----------------------------------------------------------------------------------------------------------
  const guard = seq.nCross * 4 + 100;
  let stall = 0;
  while (seq.madeN < seq.nCross && seq.round < guard) {
    let acted = false;
    for (const wr of weavers) {
      if (seq.madeN >= seq.nCross) break;
      const L = frontLevel(wr), cache = new Map();
      const choose = (list) => { let best = null; for (const [e, d] of list) { const plan = planOf(e, wr.wv, cache); if (!plan) continue; const c = cost(wr, e, plan, d); if (!best || c < best.c || (c === best.c && e < best.e)) best = { e, c }; } return best; };
      // the ring: crossings of the current level (one ahead with `ahead`), near ones by lattice distance, the rest of the
      // ring wherever it is; the next ring only when nothing is left to do on this one
      let cands = [], best = null;
      if (together) {
        // my ring: from my level up (never back down), the crossings nearer to me than to the weavers still working at or
        // below that level; a crossing left below everyone's ring goes to the nearest weaver first
        wr.Lw = Math.max(wr.Lw ?? 0, L);
        const lv = new Map();
        for (let e = 0; e < w.nE; e++) {
          if (!seq.isCross[e] || seq.made[e] || wr.elev[e] > wr.Lw + 2) continue;
          const l = wr.elev[e], dm = wr.dmap[e], below = l < wr.Lw && !weavers.some(o => o.Lw <= l);
          let own = true;
          for (const o of weavers) if (o !== wr && (below || o.Lw <= l) && (o.dmap[e] < dm || (o.dmap[e] === dm && o.wv < wr.wv))) { own = false; break; }
          if (!own || (l < wr.Lw && !below)) continue;
          if (!lv.has(l)) lv.set(l, []); lv.get(l).push([e, Math.max(1, dm)]);
        }
        for (const l of [...lv.keys()].sort((x, y) => x - y)) { best = choose(lv.get(l)); if (best) { if (l > wr.Lw) wr.Lw = l; break; } }
      } else if (wr.last < 0) cands = [...new Set(wr.seed.flatMap(v => seq.cellCross[v]))].filter(e => !seq.made[e] && wr.elev[e] <= L + ahead).map(e => [e, 1]);
      else {
        cands = near(wr.last).filter(([e]) => wr.elev[e] <= L + ahead);
        const seen = new Set(cands.map(c => c[0]));
        for (let e = 0; e < w.nE; e++) if (seq.isCross[e] && !seq.made[e] && wr.elev[e] <= L && !seen.has(e)) cands.push([e, seq.crossDistance(wr.last, e, R + 1)]);
      }
      if (!together) best = choose(cands);
      for (let widen = 1; !best && widen <= 2; widen++) {
        const list = []; for (let e = 0; e < w.nE; e++) if (seq.isCross[e] && !seq.made[e] && (widen === 2 || wr.elev[e] <= L + 1)) list.push([e, wr.last < 0 ? 1 : seq.crossDistance(wr.last, e, R + 1)]);
        best = choose(list);
      }
      if (!best && repair(wr)) { const list = []; for (let e = 0; e < w.nE; e++) if (seq.isCross[e] && !seq.made[e]) list.push([e, wr.last < 0 ? 1 : seq.crossDistance(wr.last, e, R + 1)]); best = choose(list); }
      if (best) { act(wr, best.e); acted = true; if (together) wr.dmap = distFrom([best.e]); } else wr.idle++;
    }
    runJoins(0);
    seq.round++;
    stall = acted ? 0 : stall + 1; if (stall > 2) break;
  }
  runJoins(0);
  // --- labels: strands by first use, pieces by birth -------------------------------------------------------------------
  const firstUse = new Map(); for (const P of seq.pieces) if (!firstUse.has(P.si) || P.born < firstUse.get(P.si)) firstUse.set(P.si, P.born);
  const strandRank = [...firstUse.keys()].sort((a, b) => firstUse.get(a) - firstUse.get(b) || a - b), label = new Map(strandRank.map((si, r) => [si, r + 1]));
  const perStrand = new Map();
  for (const P of [...seq.pieces].sort((a, b) => a.born - b.born || a.id - b.id)) { const n = (perStrand.get(P.si) || 0) + 1; perStrand.set(P.si, n); P.n = n; }
  for (const P of seq.pieces) P.label = perStrand.get(P.si) > 1 ? `S${label.get(P.si)}.${P.n}` : `S${label.get(P.si)}`;
  // --- metrics via replay (comparable with the baseline): own crossings only, the joint belongs to the strip that made it;
  //     the physical length includes the joints -------------------------------------------------------------------------
  const weaveEvents = seq.events.filter(ev => ev.kind === 'weave');
  const order = weaveEvents.map(ev => ev.e), weaverOf = weaveEvents.map(ev => ev.weaver), movers = weaveEvents.map(ev => ev.mover);
  const pieces = seq.pieces.map(P => ({ si: P.si, knots: P.knots.slice(P.ovTail, P.knots.length - P.ovHead), label: P.label }));
  const lengths = seq.pieces.map(P => spanLength(P.si, P.u0, P.u0 + P.knots.length - 1));
  const metrics = replay(w, pieces, order, { G, k, Lmax: Number.isFinite(Lmax) ? Lmax : 0, lengths, weaverOf, movers, weavers: K });
  return {
    K, seeds, origin, front: origin ? 'together' : 'rims', startWhy, G, k, Lmax, Lcut, events: seq.events, order, pieces: seq.pieces, lengths, strandLabel: label, metrics, levels: weavers.map(wr => wr.elev), aMed,
    rounds: seq.round, idle: weavers.map(wr => wr.idle), acts: weavers.map(wr => wr.acts), joins, handovers, seams, cuts, shortJoints, overLong,
    strandedMean: actions ? strandedSum / actions : 0, strandedMax,
    complete: seq.madeN === seq.nCross, madeN: seq.madeN, nCross: seq.nCross, pendingJoins: pendingJ.size, seq,
  };
}

/** the rim of the lattice as loops of boundary cells (connected groups of boundary cells) */
export function boundaryLoops(w, nbr) {
  const seen = new Uint8Array(w.nV), loops = [];
  for (let v = 0; v < w.nV; v++) {
    if (!w.boundary[v] || seen[v]) continue;
    const loop = [v]; seen[v] = 1;
    for (let q = 0; q < loop.length; q++) for (const u of nbr[loop[q]]) if (w.boundary[u] && !seen[u]) { seen[u] = 1; loop.push(u); }
    loops.push(loop);
  }
  return loops;
}
/** the start of the rings when none is given: the lowest rim (a tube from its bottom ring, a tree from its trunk base, the
 *  columns from a foot; a closed shape from the lower end of its longest axis) — unless from that rim most strands would
 *  turn back. A strand whose level rises and falls again is woven from both ends towards the middle, so it needs a joint
 *  there (R9): a cone from its rim turns every strand, from its apex none. Then the start is the candidate with the
 *  fewest turns (the singular cells, the centre of the lattice, the lower end of the longest axis, the other rims), if it
 *  has fewer than half. Returns { src, kind, turns, base: { kind, turns, strands, size } }. */
export function autoStart(w, nbr = neighbours(w)) {
  const loops = boundaryLoops(w, nbr), zOf = (l) => l.reduce((s, v) => s + w.V[3 * v + 2], 0) / l.length;
  loops.sort((A, B) => zOf(A) - zOf(B) || A.length - B.length);
  const cands = loops.map(l => ({ src: l.slice(), kind: 'rim' }));
  const sing = []; for (let v = 0; v < w.nV; v++) if (!w.boundary[v] && w.valence[v] !== 6) sing.push(v);
  if (sing.length <= 64) for (const v of sing) cands.push({ src: [v], kind: 'singular' });
  cands.push({ src: [graphCentre(w, nbr)], kind: 'centre' }, { src: [axisEnd(w)], kind: 'axis' });
  const measure = (c) => { const lev = hopDistance(w, c.src, nbr); Object.assign(c, strandTurns(w, lev)); let m = 0; for (const x of lev) if (x > m) m = x; c.ecc = m; return c; };
  const base = measure(loops.length ? cands[0] : cands[cands.length - 1]), rank = { rim: 0, singular: 1, centre: 2, axis: 3 };
  let pick = base;
  if (loops.length && base.strands >= 0.5 * w.strands.length) {
    let best = base;
    for (const c of cands) { if (c === base) continue; measure(c); if (c.turns < best.turns || (c.turns === best.turns && (rank[c.kind] < rank[best.kind] || (c.kind === best.kind && c.ecc < best.ecc)))) best = c; }
    if (best.turns < 0.5 * base.turns) pick = best;
  }
  return { src: pick.src, kind: pick.kind, turns: pick.turns, base: { kind: base.kind, turns: base.turns, strands: base.strands, size: base.src.length } };
}
/** the strands that turn back: interior strict maxima of the level along each strand (a plateau counted once) →
 *  { turns, strands (that turn at least once) } */
export function strandTurns(w, lev) {
  let turns = 0, strands = 0;
  for (const s of w.strands) {
    const t0 = turns;
    const n = s.knots.length, L = s.knots.map(e => { const [a, b] = w.edges[e]; return Math.max(lev[a], lev[b]); });
    const get = (i) => L[((i % n) + n) % n];
    for (let i = 0; i < n; i++) {
      if (!s.closed && (i === 0 || i === n - 1)) continue;
      if (get(i) === get(i - 1)) continue;
      let j = i; while ((s.closed ? j - i < n : j < n - 1) && get(j + 1) === get(i)) j++;
      if (!s.closed && j >= n - 1) continue;
      if (get(i - 1) < get(i) && get(j + 1) < get(i)) turns++;
    }
    if (turns > t0) strands++;
  }
  return { turns, strands };
}
/** a cell near the centre of the lattice (by hops): between the two ends of a double sweep */
export function graphCentre(w, nbr = neighbours(w)) {
  const far = (d) => { let b = 0; for (let v = 0; v < w.nV; v++) if (d[v] > d[b]) b = v; return b; };
  const p = far(hopDistance(w, [0], nbr)), dp = hopDistance(w, [p], nbr), q = far(dp), dq = hopDistance(w, [q], nbr);
  let best = 0, bs = Infinity; for (let v = 0; v < w.nV; v++) { if (dp[v] < 0 || dq[v] < 0) continue; const s = Math.max(dp[v], dq[v]) * 1000 + Math.abs(dp[v] - dq[v]); if (s < bs) { bs = s; best = v; } }
  return best;
}
/** the default seeds of K weavers, each from its own front: the start above, then the other rims from the lowest up,
 *  then the cells farthest from the seeds so far */
export function autoSeeds(w, K, nbr = neighbours(w)) {
  const loops = boundaryLoops(w, nbr), z = (l) => l.reduce((s, v) => s + w.V[3 * v + 2], 0) / l.length;
  loops.sort((A, B) => z(A) - z(B) || A.length - B.length);
  const first = autoStart(w, nbr).src, inFirst = new Set(first);
  const seeds = [first, ...loops.filter(l => !l.some(v => inFirst.has(v))).map(l => l.slice())].slice(0, K);
  return fillSeeds(w, nbr, seeds, K);
}
/** K start cells spread along a start (a rim loop, or a cell and the rings around it until there are K cells): the
 *  lowest first, then each the farthest from those chosen */
export function spreadStarts(w, nbr, origin, K) {
  const lev = hopDistance(w, origin, nbr);
  let cand = origin.slice();
  for (let r = 1; cand.length < K && r < w.nV; r++) { cand = []; for (let v = 0; v < w.nV; v++) if (lev[v] >= 0 && lev[v] <= r) cand.push(v); }
  const z = (v) => w.V[3 * v + 2];
  const out = [cand.reduce((b, v) => (z(v) < z(b) ? v : b), cand[0])];
  while (out.length < K && out.length < cand.length) {
    const d = hopDistance(w, out, nbr); let best = -1, bd = -1;
    for (const v of cand) if (d[v] > bd) { bd = d[v]; best = v; }
    if (best < 0 || bd <= 0) break; out.push(best);
  }
  return out;
}
/** add seeds (single cells) farthest from the ones there, up to K */
export function fillSeeds(w, nbr, seeds, K) {
  const out = seeds.map(s => s.slice());
  while (out.length < K) { const d = hopDistance(w, out.flat(), nbr); let best = -1, bd = -1; for (let v = 0; v < w.nV; v++) if (d[v] > bd) { bd = d[v]; best = v; } if (best < 0) break; out.push([best]); }
  return out;
}
/** the cell at the lower end of the longest axis of the shape (principal axis of the cells, oriented upward) */
export function axisEnd(w) {
  const n = w.nV, c = [0, 0, 0]; for (let v = 0; v < n; v++) for (let q = 0; q < 3; q++) c[q] += w.V[3 * v + q] / n;
  const C = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  for (let v = 0; v < n; v++) { const d = [w.V[3 * v] - c[0], w.V[3 * v + 1] - c[1], w.V[3 * v + 2] - c[2]]; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) C[i][j] += d[i] * d[j]; }
  let u = [0.3, 0.5, 0.8]; for (let it = 0; it < 60; it++) { const x = [0, 1, 2].map(i => C[i][0] * u[0] + C[i][1] * u[1] + C[i][2] * u[2]), l = Math.hypot(...x) || 1; u = x.map(t => t / l); }
  if (u[2] < -1e-6 || (Math.abs(u[2]) <= 1e-6 && u[0] < 0)) u = u.map(t => -t);
  let best = 0, bp = Infinity; for (let v = 0; v < n; v++) { const p = (w.V[3 * v] - c[0]) * u[0] + (w.V[3 * v + 1] - c[1]) * u[1] + (w.V[3 * v + 2] - c[2]) * u[2]; if (p < bp) { bp = p; best = v; } }
  return best;
}
