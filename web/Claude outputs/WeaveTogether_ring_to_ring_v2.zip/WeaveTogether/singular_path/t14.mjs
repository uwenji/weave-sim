// t14.mjs — several weavers: one front per rim (fronts meet head-on: a seam, joints) against one front shared by all
// (the weavers side by side on the same ring: strips pass from hand to hand). Ji's reference cases at his scale.
//   node t14.mjs [--K 2,3] [--scale 0.3355] [--overlap 3] [--cases a,b]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseOBJ, buildWeave, orientConsistent, orientOutward, medianEdge } from './js/weave.js';
import { planSequence } from './js/sequence.js';
const here = path.dirname(fileURLToPath(import.meta.url));
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const KS = arg('K', '1,2,3').split(',').map(Number), SCALE = +arg('scale', 0.33551202540523895), OVER = +arg('overlap', 3);
const LENS = { Tube_216: 600, Tube_230: 600, treeBig_527: 800, twocolumn_529: 60 };
const only = arg('cases', '') ? arg('cases', '').split(',') : null;
const cm = (u) => u * SCALE, f0 = (x) => (Number.isFinite(x) ? x.toFixed(0) : '–');
console.log('| case | K | front | rounds | strips | joints | hand-overs | seam | loose mean | loose max | hang | jumps (far) | rings | idle | ms |');
console.log('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|');
for (const f of fs.readdirSync(path.join(here, 'models')).filter(f => f.endsWith('.obj')).sort()) {
  const id = f.replace(/_v\d+_(\d+)v\.obj$/, '_$1'); if (only && !only.includes(id)) continue;
  const d = parseOBJ(fs.readFileSync(path.join(here, 'models', f), 'utf8')), V = Float64Array.from(d.V), F = Int32Array.from(d.F); orientConsistent(F); orientOutward(V, F);
  const w = buildWeave(V, F), a = medianEdge(w), Lmax = LENS[id] ? LENS[id] / SCALE : 12 * a, unit = LENS[id] ? cm : (u) => u / a;
  for (const K of KS) for (const front of K > 1 ? ['rims', 'together'] : ['rims']) {
    const t0 = performance.now(), p = planSequence(w, { K, Lmax, k: OVER, G: 1, front }), ms = Math.round(performance.now() - t0), m = p.metrics;
    let ok = 0, n = 0; const top = new Array(p.K).fill(-1);
    for (const ev of p.events) { if (ev.kind !== 'weave') continue; const lv = p.levels[ev.weaver][ev.e]; n++; if (lv >= top[ev.weaver]) ok++; top[ev.weaver] = Math.max(top[ev.weaver], lv); }
    console.log(`| ${id} | ${K} | ${front}${p.complete ? '' : ' ⚠'} | ${p.rounds} | ${m.pieces} | ${p.joins} | ${p.handovers} | ${p.seams} | ${f0(unit(m.loadMean))}${LENS[id] ? ' cm' : ' a'} | ${f0(unit(m.loadMax))} | ${Math.round(100 * m.hangMean / m.steps)}% | ${m.jumpCount} (${m.jumpFar}) | ${(ok / Math.max(1, n)).toFixed(2)} | ${p.idle.join('+')} | ${ms} |`);
  }
}
