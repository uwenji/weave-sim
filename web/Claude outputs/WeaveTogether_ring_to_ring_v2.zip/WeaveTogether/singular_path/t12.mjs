// t12.mjs — Ji's reference cases (8 Nov evening): the open tubes with 600 cm strips (no cut: the marching path alone),
// the tree with 800 cm, the two columns with 60 cm — at his scale (cm per model unit) and joint overlap — for the cell
// tour (best start rule, as the app's auto) and the sequence planner with 1–3 weavers (one front, together — the
// default; t14.mjs compares one front per rim); then the cut-length sweep for the
// remainder load (point 4: a long remainder weighs).
//   node t12.mjs [--scale 0.3355] [--overlap 3] [--K 1,2,3] [--sweep 1,0.5,0.25] [--json out.json]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseOBJ, buildWeave, orientConsistent, orientOutward, medianEdge } from './js/weave.js';
import { planWeave } from './js/planner.js';
import { replay, planToSequence } from './js/sequencer.js';
import { planSequence } from './js/sequence.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const arg = (name, dflt) => { const i = process.argv.indexOf('--' + name); return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : dflt; };
const SCALE = +arg('scale', 0.33551202540523895), OVERLAP = +arg('overlap', 3), KS = arg('K', '1,2,3').split(',').map(Number), SWEEP = arg('sweep', '1,0.5,0.25').split(',').map(Number), jsonOut = arg('json', '');
const CASES = [['Tube_230', 'Tube_v6_230v.obj', 600], ['Tube_216', 'Tube_v6_216v.obj', 600], ['treeBig_527', 'treeBig_v9_527v.obj', 800], ['twocolumn_529', 'twocolumn_v9_529v.obj', 60]];
const cm = (u) => u * SCALE, f0 = (x) => (Number.isFinite(x) ? x.toFixed(0) : '–'), f1 = (x) => (Number.isFinite(x) ? x.toFixed(1) : '–'), f2 = (x) => (Number.isFinite(x) ? x.toFixed(2) : '–');
const all = [];
console.log(`# reference cases — ${new Date().toISOString().slice(0, 10)}\n\nscale ${SCALE.toFixed(4)} cm per model unit, joint overlap k = ${OVERLAP}, G = 1. Loose = strip hanging from the object (the remainders of the open pieces), in cm; hang = how long a piece stays open, as a share of the whole sequence. Rings: share of crossings made in level order (1.00 = strictly ring after ring).\n`);
for (const [id, file, lenCm] of CASES) {
  const d = parseOBJ(fs.readFileSync(path.join(here, 'models', file), 'utf8')), V = Float64Array.from(d.V), F = Int32Array.from(d.F); orientConsistent(F); orientOutward(V, F);
  const w = buildWeave(V, F), a = medianEdge(w), Lmax = lenCm / SCALE;
  console.log(`### ${id} — ${w.nV} cells · ${w.nE} edges · ${w.strands.length} strands · a = ${f1(cm(a))} cm · material ${lenCm} cm = ${f1(Lmax / a)} a · strands ${f0(cm(Math.min(...w.strandLen)))}–${f0(cm(Math.max(...w.strandLen)))} cm`);
  console.log('| plan | K | rounds | pieces | joins | hand-overs | hang mean | loose mean | loose max | longest remainder | gaps>1 | jumps | far≥4 | fronts | rings | R7 sing | R8 | ms |');
  console.log('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|');
  const row = (name, K, m, extra, ms) => {
    const r = { case: id, plan: name, K, lenCm, ...extra, ...m }; delete r.seq; all.push(r);
    console.log(`| ${name} | ${K} | ${extra.rounds ?? m.steps} | ${m.pieces} | ${extra.joins ?? '–'} | ${extra.handovers ?? '–'} | ${Math.round(100 * m.hangMean / m.steps)}% | ${f0(cm(m.loadMean))} cm | ${f0(cm(m.loadMax))} cm | ${f0(cm(m.remMax))} cm | ${m.gapViolations} | ${m.jumpCount} | ${m.jumpFar} | ${m.frontsMax} | ${extra.rings ?? '–'} | ${f2(m.spreadSingular)} | ${f1(m.stressMean)} | ${ms} |`);
  };
  // the cell tour, best of the four start rules by total hanging (the app's auto)
  { const t0 = performance.now(); let best = null;
    for (const rule of ['half', 'centre', 'flat', 'rim']) {
      const plan = planWeave(w, { strategy: 'spiral', rule, maxLength: Lmax, overlap: OVERLAP, distribution: 'start', hold: 6 });
      const { pieces, order, lengths } = planToSequence(w, plan), m = replay(w, pieces, order, { G: 1, k: OVERLAP, Lmax, lengths });
      if (!best || m.hangSum < best.m.hangSum) best = { m, rule };
    }
    row(`cell tour (${best.rule})`, 1, best.m, {}, Math.round(performance.now() - t0)); }
  // the sequence planner
  for (const K of KS) {
    const t0 = performance.now(), p = planSequence(w, { K, Lmax, k: OVERLAP, G: 1 }), ms = Math.round(performance.now() - t0);
    // rings: per weaver, the share of its crossings whose level is not below the highest level it has reached
    let ok = 0, n = 0; const top = new Array(K).fill(-1);
    for (const ev of p.events) { if (ev.kind !== 'weave') continue; const lv = p.levels[ev.weaver][ev.e]; n++; if (lv >= top[ev.weaver]) ok++; top[ev.weaver] = Math.max(top[ev.weaver], lv); }
    row(`rings (${p.origin ? `together from ${p.origin.length > 1 ? `rim ${p.origin.length}` : 'a cell'}` : p.seeds.map(s => s.length > 1 ? `rim ${s.length}` : 'cell').join(' + ')})${p.complete ? '' : ' ⚠ incomplete'}`, K, p.metrics, { rounds: p.rounds, joins: p.joins, handovers: p.handovers, rings: (ok / Math.max(1, n)).toFixed(2), seams: p.seams }, ms);
  }
  console.log('');
}
// the cut-length sweep: strips cut shorter than the material (more joints) against the load of the remainders
console.log(`## cut length vs load (one weaver; the cut is a fraction of the material, or of the longest strand when every strand fits)\n\n| case | cut | pieces | joins | joints with < k crossings | loose mean | loose max | longest remainder | hang mean |\n|---|---|---|---|---|---|---|---|---|`);
for (const [id, file, lenCm] of CASES) {
  const d = parseOBJ(fs.readFileSync(path.join(here, 'models', file), 'utf8')), V = Float64Array.from(d.V), F = Int32Array.from(d.F); orientConsistent(F); orientOutward(V, F);
  const w = buildWeave(V, F), a = medianEdge(w);
  const base = Math.min(lenCm, cm(Math.max(...w.strandLen)));               // the material, or the longest strand when every strand fits
  for (const f of SWEEP) {
    const cut = base * f, p = planSequence(w, { K: 1, Lmax: cut / SCALE, k: OVERLAP, G: 1 }), m = p.metrics;
    all.push({ case: id, plan: 'sweep', cutCm: cut, ...m, joins: p.joins, seq: undefined });
    console.log(`| ${id} | ${f0(cut)} cm (${f1(cut / SCALE / a)} a) | ${m.pieces} | ${p.joins} | ${p.shortJoints || '–'} | ${f0(cm(m.loadMean))} cm | ${f0(cm(m.loadMax))} cm | ${f0(cm(m.remMax))} cm | ${Math.round(100 * m.hangMean / m.steps)}% |`);
  }
}
if (jsonOut) { fs.writeFileSync(jsonOut, JSON.stringify(all, null, 1)); console.log(`\nwritten ${jsonOut}`); }
