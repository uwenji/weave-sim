// t13.mjs — the sequence planner as the viewer reads it (js/seqplan.js): every crossing made once at a fractional
// sub-step inside its run, the runs' ticks in order, strips picked up no later than their first crossing, the mover
// through each of its crossings, pieces laid along their strands as the walk says, cells closed once.
//   node t13.mjs [--K 1,2,3] [--cases Tube_230,…] [--scale 0.3355] [--len 60] [--overlap 3]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseOBJ, buildWeave, orientConsistent, orientOutward, medianEdge } from './js/weave.js';
import { SYNTHETIC } from './js/lattices.js';
import { sequenceViewPlan } from './js/seqplan.js';
const here = path.dirname(fileURLToPath(import.meta.url));
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const KS = arg('K', '1,2,3').split(',').map(Number), SCALE = +arg('scale', 0.33551202540523895), OVER = +arg('overlap', 3);
const LENS = { Tube_216: 600, Tube_230: 600, treeBig_527: 800, twocolumn_529: 60 };   // Ji's reference cases (cm); the others 12 a
const only = arg('cases', '') ? arg('cases', '').split(',') : null;
const cases = [];
for (const [id, s] of Object.entries(SYNTHETIC)) cases.push({ id, load: () => s.make() });
for (const f of fs.readdirSync(path.join(here, 'models')).filter(f => f.endsWith('.obj')).sort()) cases.push({ id: f.replace(/_v\d+_(\d+)v\.obj$/, '_$1'), load: () => parseOBJ(fs.readFileSync(path.join(here, 'models', f), 'utf8')) });
let fails = 0;
for (const c of cases.filter(c => !only || only.includes(c.id))) {
  const d = c.load(), V = Float64Array.from(d.V), F = Int32Array.from(d.F); orientConsistent(F); orientOutward(V, F);
  const w = buildWeave(V, F), a = d.meta && d.meta.a ? d.meta.a : medianEdge(w);
  for (const [K, front] of KS.flatMap(K => (K > 1 ? [[K, 'together'], [K, 'rims']] : [[K, 'together']]))) {
    const Lmax = LENS[c.id] ? LENS[c.id] / SCALE : 12 * a, t0 = performance.now(), plan = sequenceViewPlan(w, { K, front, Lmax, k: OVER, G: 1, hold: 6 }), ms = Math.round(performance.now() - t0);
    const errs = [], S = plan.steps, n = S.length - 1;
    for (let e = 0; e < w.nE; e++) { if (plan.rim[e] || w.knotStrands[e].length !== 2) continue; const ks = plan.knotStep[e]; if (!(ks > 0 && ks < n)) errs.push(`crossing ${e} at ${ks}`); }
    const seen = new Map();
    S.forEach((st, k) => {
      if (st.kind === 'done') return;
      let prev = -1;
      st.knots.forEach((q, i) => {
        if (q.join) { if (!(plan.knotStep[q.e] < k + (i + 1) / (st.nTicks + 1) + 1e-9)) errs.push(`step ${k}: joint through an unwoven crossing ${q.e}`); return; }
        const ks = plan.knotStep[q.e]; if (Math.floor(ks) !== k || ks <= prev) errs.push(`step ${k} tick ${i}: knotStep ${ks}`); prev = ks;
        if (seen.has(q.e)) errs.push(`crossing ${q.e} made twice`); seen.set(q.e, k);
        if (!q.lay && q.pos < 0) errs.push(`step ${k}: the strip in hand ${st.piece.label} does not pass crossing ${q.e}`);
        for (const pc of [q.pcOver, q.pcUnder]) if (pc && pc.intro > k) errs.push(`step ${k}: ${pc.label} used before it is picked up (${pc.intro})`);
      });
    });
    for (const pc of plan.pieceList) {
      const s = w.strands[pc.strand], K2 = s.knots.length;
      pc.knots.forEach((i, m) => { const q = pc.q0 + m, j = s.closed ? ((q % K2) + K2) % K2 : q; if (j !== i) errs.push(`${pc.label}: knot ${m} is ${i}, the walk says ${j}`); });
      if (!(pc.length > 0) || pc.length > Lmax * 1.0001) errs.push(`${pc.label}: length ${pc.length} > ${Lmax}`);
    }
    plan.pieces.forEach((P, si) => { for (let j = 1; j < P.list.length; j++) if (P.list[j].id !== P.list[j - 1].id + 1 || P.list[j].q0 < P.list[j - 1].q0) errs.push(`strand ${si}: pieces out of order`); });
    for (let v = 0; v < w.nV; v++) if (plan.stepOf[v] < 0 || plan.stepOf[v] > n) errs.push(`cell ${v} closes at ${plan.stepOf[v]}`);
    const sm = plan.summary;
    console.log(`${errs.length ? '✗' : '✓'} ${c.id.padEnd(18)} K=${K}${K > 1 ? " " + front : ""} · ${n} runs · ${plan.nPiecesAll} strips · ${sm.joins} joints · ${sm.handovers} hand-overs · ${sm.rounds} rounds · complete ${sm.complete} · ${ms} ms${errs.length ? '\n   ' + errs.slice(0, 6).join('\n   ') + (errs.length > 6 ? `\n   … ${errs.length - 6} more` : '') : ''}`);
    if (errs.length) fails++;
  }
}
console.log(fails ? `${fails} plan(s) with errors` : 'all plans consistent');
process.exitCode = fails ? 1 : 0;
